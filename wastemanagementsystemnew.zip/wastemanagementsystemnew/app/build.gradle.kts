plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services") // Firebase services plugin
}

android {
    namespace = "com.example.wastemanagement"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.wastemanagement"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        viewBinding = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Material Design
    implementation("com.google.android.material:material:1.12.0")

    // Firebase Auth (use BOM to manage versions)
    implementation(platform("com.google.firebase:firebase-bom:32.2.2"))
    implementation("com.google.firebase:firebase-auth-ktx")

    // Optional: Firestore if you want user data
    implementation("com.google.firebase:firebase-firestore-ktx")

    // Jetpack Navigation
    implementation("androidx.navigation:navigation-fragment-ktx:2.7.3")
    implementation("androidx.navigation:navigation-ui-ktx:2.7.3")
}

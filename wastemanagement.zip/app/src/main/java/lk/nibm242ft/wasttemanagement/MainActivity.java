package lk.nibm242ft.wasttemanagement;

import android.app.Activity;

public class MainActivity extends Activity {
}
